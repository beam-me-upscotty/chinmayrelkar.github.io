import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import java.util.Scanner;

public class AES {
    static Cipher cipher;

    public static void main(String[] args) throws Exception {
        //initialize keygenerator for 128 bit key generation
        KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
        keyGenerator.init(128);
        
        //generate secret key using generator
        SecretKey secretKey = keyGenerator.generateKey();
        
        //initialize java class to encrypt and decrypt data
        cipher = Cipher.getInstance("AES");
        
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter plain text: ");
        String plainText = scanner.nextLine();
        System.out.println("Plain Text Before Encryption: " + plainText);

        String encryptedText = encrypt(plainText, secretKey);
        System.out.println("Encrypted Text After Encryption: " + encryptedText);

        String decryptedText = decrypt(encryptedText, secretKey);
        System.out.println("Decrypted Text After Decryption: " + decryptedText);
    }

    public static String encrypt(String plainText, SecretKey secretKey) throws Exception {
        byte[] plainTextByte = plainText.getBytes();
        //encrypt using cipher instance by putting instance in encrypt mode
        cipher.init(Cipher.ENCRYPT_MODE, secretKey);
        //encrypt bytecode of plaintext
        byte[] encryptedByte = cipher.doFinal(plainTextByte);
        //initialize Base64 encoder to encode bytes into string of Base64 scheme
        Base64.Encoder encoder = Base64.getEncoder();
        String encryptedText = encoder.encodeToString(encryptedByte);
        return encryptedText;
    }

    public static String decrypt(String encryptedText, SecretKey secretKey) throws Exception {
        //initialize decoder to get bytecode from encrypted string
        Base64.Decoder decoder = Base64.getDecoder();
        byte[] encryptedTextByte = decoder.decode(encryptedText);
        //initialize cipher instance to decrypt mode
        cipher.init(Cipher.DECRYPT_MODE, secretKey);
        byte[] decryptedByte = cipher.doFinal(encryptedTextByte);
        //convert bytecode to string by constructor
        String decryptedText = new String(decryptedByte);
        return decryptedText;
    }
}