import java.util.*;
import java.math.*;

class RSAme
{
	static double p,q,d,e,phi,n,msg,x,c;
	
	public static void main(String [] args)
	{
		RSAme obj = new RSAme();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter 1st prime no. : ");
		p = sc.nextDouble();
		
		System.out.println("Enter 2st prime no. : ");
		q = sc.nextDouble();
		
		n = p*q;
		phi = (p-1)*(q-1);
		
		for(e=2; e<phi; e++)
		{
			if(obj.gcd(e,phi)==1)
			{
				break;
			}
		}
		
		System.out.println("Value of e : "+e);
		for(int i=0; i<100; i++)
		{
			x = (i*phi)+1;
			if(x%e == 0)
			{
				d = x/e;
				break;
			}
		}
		
		System.out.println("Value of d : "+d);
		System.out.println("Enter the msg : ");
		msg = sc.nextDouble();
		
		System.out.println("Entered Msg : "+msg);
		c = Math.pow(msg ,e)%n;
		System.out.println("Chiphered text is : "+c);
		BigInteger N = BigInteger.valueOf((long) n);
		BigInteger C = BigInteger.valueOf((long) c);
		
		BigInteger plain = C.pow((int) d).mod(N);
		System.out.println("Dycryped msg is : "+plain);
	}
	
	double gcd(double e, double z)
	{
		if(e==0)
			return z;
		else
			return(gcd(z%e,e));
	}
}
