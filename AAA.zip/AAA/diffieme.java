import java.util.*;
import java.math.*;

public class diffieme
{
	public static void main(String [] args)
	{
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter 1st prime no. : ");
		BigInteger p = new BigInteger(sc.next());
		
		System.out.println("Enter 2nd prime no. : ");
		BigInteger q = new BigInteger(sc.next());
		
		System.out.println("Enter Ramesh's secret no. : ");
		BigInteger a = new BigInteger(sc.next());
		
		BigInteger R = q.modPow(a , p);
	
		System.out.println("Ramesh sends R to Suresh :" +R);
		
		System.out.println("Enter Suresh's secret no. : ");
		BigInteger b = new BigInteger(sc.next());
		
		BigInteger S = q.modPow(b , p);
		
		System.out.println("Suresh send S to Ramesh : " +S);
		
		BigInteger Rk = S.modPow(a , p);
		BigInteger Sk = R.modPow(b , p);
		
		System.out.println("Secert Key by Ramesh is : " +Rk);
		System.out.println("Secert Key by Suresh is : " +Sk);
	}
		
	
}
