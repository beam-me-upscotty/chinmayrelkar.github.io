import numpy as np
import matplotlib.pyplot as plt

def main():
	
	x = np.array([9,4,10,15,6,23,45,18])
	y = np.array([20,5,16,7,41,8,1,75])
	
	b = cal_coeff(x , y)
	print("Coefficients are : ")
	print("b0 = {}".format(b[0]))
	print("b1 = {}".format(b[1]))
	
	plot_line(x , y , b)


def cal_coeff(x,y):
	n = np.size(x)
	mx , my = np.mean(x) , np.mean(y)
	
	SS_xy = np.sum(y*x) - n*mx*my
	SS_xx = np.sum(x*x) - n*mx*mx
	
	b1 = SS_xy/SS_xx
#	y = b0 + b1x
	b0 = my - mx*b1
	return(b0 , b1)

def plot_line(x,y,b):
	plt.scatter(x, y, color='m', marker="o", s=30)
	pred = b[0]+b[1]*x
	plt.plot(x,pred, color='g')
	plt.xlabel('x')
	plt.ylabel('y')
	plt.show()


if __name__ == '__main__':
	main()
