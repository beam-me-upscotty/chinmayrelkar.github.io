#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<netinet/in.h>

int main(){
	struct sockaddr_in saddr;
	int cd,b;
	char data[20],fdata[100];

	cd = socket(AF_INET , SOCK_STREAM , 0);
	if(cd < 0){
		printf("SOCKET ERROR");
		exit(1);
	}
	
	saddr.sin_family = AF_INET;
	saddr.sin_port = htons(8000);
	saddr.sin_addr.s_addr = INADDR_ANY;

	b = connect(cd , (struct sockaddr*) &saddr , sizeof(saddr));
	if(b == -1){
		printf("Connection error");
		exit(1);
	}

	int index = recv(cd , data , 20 ,0);
	data[index] = '\0';
	printf("\nSERVER: %s", data);

	printf("\nEnter data to be sent\n");
	gets(data);
	index = send(cd , data , strlen(data) , 0);
	data[index] = '\0';
	//printf("\nCLIENT : %s",data);

	close(cd);
} 
