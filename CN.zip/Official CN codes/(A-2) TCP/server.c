#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<netinet/in.h>

int main(){
	struct sockaddr_in saddr , caddr;
	int sd , newsd , b;
	char senddata[20] , fdata[100];

	sd = socket(AF_INET , SOCK_STREAM , 0);
	if(sd < 0){
		printf("Error in creation");
		exit(1);
	}

	saddr.sin_family = AF_INET;
	saddr.sin_port = htons(8000);
	saddr.sin_addr.s_addr = INADDR_ANY;

	if(bind(sd , (struct sockaddr*) &saddr , sizeof(saddr)) == -1){
		printf("Error in binding");
		exit(1);
	}
	
	if(listen(sd , 5) == -1){
		printf("Error in listening");
		exit(1);
	}

	printf("Server is waiting.......\n");
	fflush(stdout);

	b = sizeof(caddr);
	newsd = accept(sd , (struct sockaddr*) &caddr , &b);
	
	if(newsd == -1){
		printf("Accepting error");
	}
	
	printf("Enter the data to be send\n");
	gets(senddata);
	int index = send(newsd , senddata , strlen(senddata) , 0);
	senddata[index] = '\0';
	//printf("SERVER: %s", senddata);

	index = recv(newsd , senddata , 20 , 0);
	senddata[index] = '\0';
	printf("CLIENT : %s", senddata);
	 
	close(newsd);
}
	
	
