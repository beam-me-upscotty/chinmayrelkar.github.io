#include<stdio.h>
#include<arpa/inet.h>
#include<sys/socket.h>
#include<unistd.h>
#include<sys/types.h>
#include<stdlib.h>
#include<string.h>
#include<error.h>
void nerror(char * msg)
{
	perror(msg);
	exit(1);
}

int main()
{
	char buffer[1024],c,filename[20];
	int sockfd = socket(AF_INET,SOCK_DGRAM,0);
	if(sockfd<0)
		nerror("Socket cannot be created");
	struct sockaddr_in server;
	server.sin_family=AF_INET;
	server.sin_addr.s_addr=inet_addr("127.0.0.1");
	server.sin_port=htons(atoi("5062"));
	int len=sizeof(struct sockaddr_in);
	printf("Enter the name of the file:");
	scanf("%s",filename);
	FILE *f;
	f=fopen(filename,"rb");
	fseek(f,0,0);
	while(fread(buffer,1024,1,f))
	{   	
		sendto(sockfd,buffer,1024,0,(struct sockaddr *)&server,len);
		usleep(1000);
	}
	strcpy(buffer,"Completed");
	sendto(sockfd,buffer,1024,0,(struct sockaddr *)&server,len);
	return 0;
}
