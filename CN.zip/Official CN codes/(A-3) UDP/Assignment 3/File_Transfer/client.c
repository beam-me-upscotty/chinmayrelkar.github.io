#include<stdio.h>
#include<arpa/inet.h>
#include<sys/socket.h>
#include<unistd.h>
#include<sys/types.h>
#include<stdlib.h>
#include<string.h>
#include<error.h>
void nerror(char * msg)
{
	perror(msg);
	exit(1);
}

int main()
{
	char c;
	int sockfd = socket(AF_INET,SOCK_DGRAM,0);
	if(sockfd<0)
		nerror("Socket cannot be created");
	struct sockaddr_in server;
	server.sin_family=AF_INET;
	server.sin_addr.s_addr=inet_addr("127.0.0.1");
	server.sin_port=htons(atoi("5052"));
	int len=sizeof(struct sockaddr_in);
	FILE *f;
	f=fopen("OutOfTheWoods.mp3","r");
	while((c=fgetc(f))!=EOF){  
		printf("%c",c);  
		sendto(sockfd,&c,1,0,(struct sockaddr *)&server,len);
	}
	c=EOF;
	sendto(sockfd,&c,1,0,(struct sockaddr *)&server,len);
}
