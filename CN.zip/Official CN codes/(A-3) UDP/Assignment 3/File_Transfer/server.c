#include<stdio.h>
#include<arpa/inet.h>
#include<sys/socket.h>
#include<unistd.h>
#include<sys/types.h>
#include<stdlib.h>
#include<error.h>
void nerror(char *msg)
{
	perror(msg);
	exit(1);
}

int main()
{
	char buffer[256],c;
	int sockfd = socket(AF_INET,SOCK_DGRAM,0);
	if(sockfd<0)
		nerror("Socket cannot be created");
	struct sockaddr_in server,client;
	server.sin_family=AF_INET;
	server.sin_addr.s_addr=INADDR_ANY;
	server.sin_port=htons(atoi("5052"));
	int len=sizeof(struct sockaddr_in);
	int bindCheck=bind(sockfd,(struct sockaddr *)&server,len);
	if(bindCheck<0)
		nerror("Binding Failed");
	int clientlen=sizeof(struct sockaddr *);
	while(1)
	{
		FILE *fp;
		fp=fopen("add1.txt","w");
		int n=recvfrom(sockfd,&c,1,0,(struct sockaddr *)&client,&clientlen);
		if(n<0)
			nerror("Error in receiving");
		if(c!=EOF)
			fputc(c,fp);
		do
		{
			n=recvfrom(sockfd,&c,1,0,(struct sockaddr *)&client,&clientlen);
			if(n<0)
				nerror("Error in receiving");
			if(c!=EOF)
				fputc(c,fp);
		}while(c!=EOF);
		exit(1);
	}
}
