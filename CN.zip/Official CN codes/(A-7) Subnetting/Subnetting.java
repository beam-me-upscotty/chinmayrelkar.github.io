import java.net.Inet4Address;
import java.util.*;

public class Subnetting {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the IP address:");
		String IPAdd=sc.next();
		System.out.println("Enter the number of subnets:");
		int number_of_subnets=sc.nextInt();

		int range_size=(256/number_of_subnets),j=0,k=range_size-1;
		for(int i=0;i<number_of_subnets;i++)
		{
			System.out.println("\nSubnet "+(i+1)+":"+j+" to "+k);
			j=j+range_size;
			k=k+range_size;

		}
		
		String [] SplitArray=IPAdd.split("\\.");
		int i;
		System.out.println("Original IP address: ");
		for(i=0;i<SplitArray.length-1;i++)
			System.out.print(SplitArray[i]+".");
		System.out.println(SplitArray[i]);
		
		int address_class=4;
		if(Integer.parseInt(SplitArray[0])<=127)
		{
			address_class=1;
			System.out.println("Class A");
			int sm=mask(number_of_subnets)+8;
			System.out.println("The subnet mask is: "+IPAdd+"/"+sm);
		}
		else if(Integer.parseInt(SplitArray[0])<=191)
		{
			address_class=2;
			System.out.println("Class B");
			int sm=mask(number_of_subnets)+16;
			System.out.println("The subnet mask is: "+IPAdd+"/"+sm);
		}
		else if(Integer.parseInt(SplitArray[0])<=223)
		{
			address_class=3;
			System.out.println("Class C");
			int sm=mask(number_of_subnets)+24;
			System.out.println("The subnet mask is: "+IPAdd+"/"+sm);
		}
	}
	public static int mask(int sm)
	{
		int count=0;
		while(sm>0)
		{
			sm=sm/2;
			count++;
		}
		return count-1;
	}
}

