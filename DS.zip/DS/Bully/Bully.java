import java.util.*;

public class Bully{
	int size;
	int leader;
	SortedSet<Integer> process;
	Scanner in;
	public Bully(){
		process = new TreeSet<Integer>();
		in = new Scanner(System.in);
	}
	public static void main(String args[]){
		Bully bully = new Bully();
		bully.run();
	}

	public void run(){
		System.out.println("Bully Election Algorithm");
		System.out.println("Enter total processes");
		size = in.nextInt();
		for(int i = 0; i < size; i++){
			System.out.println("Enter process id");
			process.add(in.nextInt());
		}
		leader = process.last();
		election();

	}
	public void election(){
		int initiator;
		while(true){
			System.out.println("Election?");
			int choice = in.nextInt();
			if(choice == 1){
				while(true){
					System.out.println("Initiator?");
					initiator = in.nextInt();
					if(process.contains(initiator) && initiator != leader){
						break;
					}
					System.out.println("Enter again");
				}
				System.out.println("Process "+initiator+" realized "+leader+" has stopped");
				process.remove(leader);
				leader = broadcast(initiator);

			}
			else{
				break;
			}
		}

	}

	public int broadcast(int initiator){

		for(int x : process){
			if(x > initiator){
				System.out.println("Process "+initiator+" sends election message to process "+x);
				System.out.println("Process "+x+ " responds with OK");

				}
		}


		for(int x : process){
			if(x > initiator){
				return broadcast(x);
			}
		}
		System.out.println("Process "+ process.last()+ " is leader");
		return initiator;
	}
}
