import java.net.*;
import java.io.*;
import java.util.*;

public class client{
	public static void main(String args[]){
		Socket socket = null;
		try{
			socket = new Socket("127.0.0.1", 7896);
			System.out.println("Client connected");
			DataInputStream in = new DataInputStream(socket.getInputStream());
			DataOutputStream out = new DataOutputStream(socket.getOutputStream());

			System.out.println("Enter a message");
			Scanner scanner = new Scanner(System.in);
			String message = scanner.next();

			out.writeUTF(message);
			System.out.println("Message sent");

			String data = in.readUTF();
			System.out.println("Data received "+data );

		}
		catch(Exception e){
			System.out.println(e);
		}
	}
}
