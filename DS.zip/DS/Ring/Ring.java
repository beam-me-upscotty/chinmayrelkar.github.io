import java.util.*;

public class Ring{
	private Scanner in;
	private SortedSet<Integer> process;
	public Ring(){
		System.out.println("Ring Election Algorithm");
		in = new Scanner(System.in);
		process = new TreeSet<Integer>();
	}
	public void showMessageList(List<Integer> pid){
		for(int x : pid){
			System.out.print(x+" ");
		}
		System.out.println();
	}
	public void showProcess(){
		System.out.println("Processes are ");
		for(int x : process){
			System.out.print(x +" ");
			}
		System.out.println();
		System.out.println(process.last()+" is co-ordinator.");
		System.out.println();
		}
	public void getInput(){
		System.out.println("Enter number of Processes");
		int size = in.nextInt();
		for(int i = 0; i < size; i++){
			System.out.println("Enter process id");
			int pid = in.nextInt();
			process.add(pid);
		}
		showProcess();
		System.out.println();
	}

	public int getNextProcess(int prev){
		boolean isPrev = false;
		for(int x : process){
			if(isPrev){
				return x;
			}
			if(x == prev){
				isPrev = true;
			}
		}
		return process.first();
	}

	public void conductElection(){
		List<Integer> message = new ArrayList<Integer>();
		int initiator, prev, next;
		while(true){
			System.out.println("Election?");
			int choice = in.nextInt();
			if(choice == 1){
				System.out.println("Process "+process.last()+" has stopped.");
				process.remove(process.last());
				while(true){
					System.out.println("Who?");
					initiator = in.nextInt();
					if(process.contains(initiator))
						break;
					else
						System.out.println("No such process exists");

				}
				prev = initiator;
				do{
					next = getNextProcess(prev);
					message.add(prev);
					System.out.println("Process " +prev+ " passed message to "+next);
					showMessageList(message);
					prev = next;
				}while(next!=initiator);
				System.out.println("Process "+ process.last()+" has become co-ordinator");
			}
			else{
				break;
			}
		}

	}


	public static void main(String args[]){
		Ring ring = new Ring();
		ring.getInput();
		ring.conductElection();
	}
}
