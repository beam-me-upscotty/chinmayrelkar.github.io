import java.io.*;
import java.net.*;
import java.util.*;

public class client{
	public static void main(String args[]){
		try{
			Socket socket = new Socket("127.0.0.1", 1234);
			System.out.println("Client connected");
			DataInputStream in = new DataInputStream(socket.getInputStream());
			DataOutputStream out = new DataOutputStream(socket.getOutputStream());

			System.out.println("Enter value in feet");
			Scanner scanner = new Scanner(System.in);
			String msg = scanner.next();

			out.writeUTF(msg);
			System.out.println("Data sent to server");

			String data = in.readUTF();
			System.out.println("Data received from server is : "+data);
		}
		catch(Exception e){
			System.out.println(e);
		}
	}
}
