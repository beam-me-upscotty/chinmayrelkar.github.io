import java.io.*;
import java.net.*;
import java.util.*;

public class server{
	public static void main(String args[]){
		while(true){
			try{
				ServerSocket ListenSocket = new ServerSocket(1234);
				System.out.println("Server Started");
				System.out.println("Waiting for client");
				Socket clientSocket = ListenSocket.accept();
				System.out.println("Client connected");
				Connection connection = new Connection(clientSocket);
			}
			catch(Exception e){
				System.out.println(e);
			}
		}
	}
}

class Connection extends Thread{
	DataInputStream in;
	DataOutputStream out;
	Socket clientSocket;

	public Connection(Socket aClientSocket){
		try{
			clientSocket = aClientSocket;
			in = new DataInputStream(clientSocket.getInputStream());
			out = new DataOutputStream(clientSocket.getOutputStream());
			this.start();
		}
		catch(Exception e){
			System.out.println(e);
		}
	}

	public void run(){
		try{
			String data = in.readUTF();
			System.out.println("Processing request with id :"+getId());
			out.writeUTF((0.3048*Float.parseFloat(data))+"");
			clientSocket.close();
		}
		catch(Exception e){
			System.out.println(e);
		}
	}
}
