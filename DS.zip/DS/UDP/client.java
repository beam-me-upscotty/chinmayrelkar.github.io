import java.net.*;
import java.util.*;

public class client{
	public static void main(String args[]){

		try{
			DatagramSocket socket = new DatagramSocket();
			InetAddress ip = InetAddress.getLocalHost();
			byte[] messageBytes = new byte[655350];

			Scanner in = new Scanner(System.in);
			String message = in.nextLine();
			messageBytes = message.getBytes();

			DatagramPacket request = new DatagramPacket(messageBytes, messageBytes.length, ip, 1234);
			socket.send(request);

			byte[] buffer = new byte[65535];
			DatagramPacket response = new DatagramPacket(buffer, buffer.length);
			socket.receive(response);
			String data = new String(buffer);
			System.out.println(data);
		}
		catch(Exception e){
			System.out.println(e);
		}
	}
}
