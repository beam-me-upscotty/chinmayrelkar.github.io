import java.net.*;

public class server{
	public static void main(String args[]){

		try{
			DatagramSocket socket = new DatagramSocket(1234);
			while(true){
				byte[] messageBytes = new byte[65535];
				DatagramPacket response = new DatagramPacket(messageBytes, messageBytes.length);
				socket.receive(response);
				System.out.println(new String(messageBytes));
				socket.send(response);
			}
		}
		catch(Exception e){
			System.out.println(e);
		}
	}

}
