#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


# In[2]:


def coef(x,y):
    n=np.size(x)
    xM,yM=np.mean(x),np.mean(y)
    b1=np.sum((x-xM)*(y-yM))/np.sum((x-xM)**2)
    b0=yM-b1*xM
    return b0,b1


# In[3]:


def plot_regression_line(x, y, b): 
    plt.scatter(x, y,color="r") 
    y_pred = b[0] + b[1]*x 
   
    plt.plot(x, y_pred, color = "g") 
  
    plt.xlabel('x') 
    plt.ylabel('y') 
 
    plt.show() 


# In[4]:


def main():  
    x = np.array([10, 9, 2, 15, 10, 16, 11, 16]) 
    y = np.array([95, 80, 10, 50, 45, 98, 38, 93]) 
   
    b = coef(x, y) 
    print("Estimated coefficients:\nb_0 = {} \nb_1 = {}".format(b[0], b[1])) 
   
    plot_regression_line(x, y, b) 
  


# In[5]:


main()


# In[ ]:




