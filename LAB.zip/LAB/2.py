#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np


# In[2]:


dataset=pd.read_csv("tree.csv")
dataset


# In[3]:


dataset["Income"].replace(["Low","Medium","High"],[0,1,2],inplace=True)
dataset["Age"].replace(["<21","21-35",">35"],[0,1,2],inplace=True)
dataset["Gender"].replace(["Male","Female"],[0,1],inplace=True)
dataset["Marital Status"].replace(["Single","Married"],[0,1],inplace=True)
dataset


# In[4]:


x=dataset[["Age","Income","Gender","Marital Status"]]
y=dataset.Buys
print(x)
print(y)


# In[5]:


from sklearn.tree import DecisionTreeClassifier
clf=DecisionTreeClassifier()
clf.fit(x,y)


# In[6]:


clf.predict([[1,2,1,1]])


# In[7]:


from sklearn.externals.six import StringIO  
from IPython.display import Image  
from sklearn.tree import export_graphviz
import pydotplus


# In[8]:


dot_data=StringIO()
export_graphviz(clf, out_file=dot_data, feature_names=["Age","Income","Gender","Marital Status"],filled=True, rounded=True,special_characters=True)
graph = pydotplus.graph_from_dot_data(dot_data.getvalue())  
Image(graph.create_png())


# In[ ]:




