#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np


# In[2]:


dataset=pd.read_csv("Knn.csv")
x=dataset[["x","y"]]
label=dataset["class"]
print(dataset)
print(x)
print(label)


# In[3]:


from sklearn.neighbors import KNeighborsClassifier
clf=KNeighborsClassifier(n_neighbors=3)
clf.fit(x,label)


# In[4]:


clf.predict([[6,6]])


# In[5]:


clf=KNeighborsClassifier(n_neighbors=3,weights="distance")
clf.fit(x,label)


# In[6]:


clf.predict([[6,2]])


# In[8]:


import matplotlib.pyplot as plt
for i in range(0,len(x)):
    if dataset['class'][i]=="positive":
        plt.scatter(x["x"][i],x["y"][i],c='r')
    else:
        plt.scatter(x["x"][i],x["y"][i],c='b')


# In[ ]:




