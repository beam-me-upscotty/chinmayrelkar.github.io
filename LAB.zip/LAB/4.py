#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


# In[2]:


x=np.array([0.10,0.15,0.08,0.16,0.20,0.25,0.24,0.30])
y=np.array([0.60,0.17,0.90,0.85,0.30,0.50,0.10,0.20])
plt.scatter(x[0],y[0],marker="*")
plt.scatter(x[7],y[7],marker="*")
plt.show()


# In[3]:


from sklearn.cluster import KMeans
cc=np.array([[0.10,0.60],[0.30,0.20]])
model=KMeans(n_clusters=2,init=cc,n_init=1)
X=np.array(list(zip(x,y)))
model.fit(X)


# In[4]:


model.predict([[0.25,0.50]])


# In[5]:


center=model.cluster_centers_
c1=center[0]
c2=center[1]
print(c1)
print(c2)


# In[6]:


cls=model.labels_
M2=0
for i in range(0,len(cls)):
    if cls[i]==1:
        M2+=1
        plt.scatter(x[i],y[i],color="r")
    else:
        plt.scatter(x[i],y[i],color="b")
plt.scatter(c1[0],c1[1],marker="*",color='b')
plt.scatter(c2[0],c2[1],marker="*",color='r')
plt.show()


# In[7]:


M2


# In[ ]:




