import java.util.*;

public class DH{
	static double R,S;
	static double Rk,Sk;
	static double a,b,p,q;

	public static void main(String args[]){
		DH d = new DH();
		Scanner sc = new Scanner(System.in);

		/****************************************************************/

		System.out.println("Enter first prime number");
		p = sc.nextDouble();

		while(d.primeCheck(p)==1){
			System.out.println("Enter valid number");
			p = sc.nextDouble();			
		}

		System.out.println("Enter first prime number");
		q = sc.nextDouble();

		while(d.primeCheck(q)==1){
			System.out.println("Enter valid number");
			q = sc.nextDouble();			
		}

		/****************************************************************/

		System.out.println("Enter secret key of R");
		a = sc.nextDouble();
		System.out.println("Enter secret key of S");
		b = sc.nextDouble();

		R = (Math.pow(q,a))%p;
		S = (Math.pow(q,b))%p;

		System.out.println("First person's R "+R);
		System.out.println("First person's S "+S);

		System.out.println("R and S are exchanged between the two users");

		System.out.println("Finding the values of Rk and Sk"); 	
		Rk = (Math.pow(S,a))%p;
		Sk = (Math.pow(R,b))%p;

		if(Rk==Sk){
			System.out.println("Rk = "+Rk+".. Sk = "+Sk);
			System.out.println("Both users agree on a key "+Rk);
			System.out.println("Communication agreed");
		}
		else{
			System.out.println("Secret keys are not same");
		}
	}
	
	public int primeCheck(double prime)
	{
		for(int i=2 ; i<prime ; i++)
		{
			if(prime%i==0)
				return 1;
		}
			
				
				return 0;
		
	}
}