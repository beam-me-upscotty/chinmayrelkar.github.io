import java.math.*;
import java.util.*;

public class RSA
{
	static double P,Q;
	static double n,e;
	static double phi_n;
	static double msg;
	static BigInteger msgback;
	static double c,x,d;
	static int i;

	public static void main(String args[])
	{

		/********************************************************************/

		Scanner sc = new Scanner(System.in);
		RSA r = new RSA();
		System.out.println("Enter first prime number");
		P = sc.nextDouble();

		while(r.primeCheck(P)==0)
		{
			System.out.println("Enter a valid prime number");
			P = sc.nextDouble();			
		}

		System.out.println("Enter second prime number");
		Q = sc.nextDouble();

		while(r.primeCheck(Q)==0)
		{
			System.out.println("Enter a valid prime number");
			Q = sc.nextDouble();			
		}

		/***********************************************************************/

		n = P*Q;
		phi_n = (P-1)*(Q-1);

		System.out.println("value of n "+phi_n);

		//find value of e

		for(e=2 ; e<phi_n ; e++)
		{
			if(r.gcd(e,phi_n)==1)
				break;
		}

		System.out.println("Value of e "+e);

		for(i=0 ; i<=9 ; i++)
		{
			x = 1+(i*phi_n);
			if(x%e==0)
			{
				d=x/e;
				break;
			}
		}

		/****************************************************************************/

		System.out.println("Enter message to be transferred");
		msg = sc.nextDouble();

		System.out.println("message entered : "+msg);

		c = (Math.pow(msg,e))%n;

		System.out.println("Encrypted message : "+c);

		BigInteger N = BigInteger.valueOf((long) n);

		/******************************************************************************/

		BigInteger C = BigDecimal.valueOf(c).toBigInteger();

		msgback = (C.pow((int)d)).mod(N);

		System.out.println("Original message "+msgback);

		sc.close();

		/****************************************************************************/
}
		public double gcd(double e,double z)
		{
			if(e==0)
				return z;
			else
				return gcd(z%e,e);
		}

		public int primeCheck(double prime)
		{
			int i;
			for(i=2 ; i<prime ; i++)
			{
				if((prime%i) == 0)
					return 0;
			}
			
			return 1;

		}


	
}