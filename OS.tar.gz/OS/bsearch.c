#include<stdio.h>
int ar[50];
int n;

void dis()
{
  int i;
   for(i=0;i<n;i++)
    {
      printf("%d\n",ar[i]);
    }
}

void sort()

{
	  int i,j,temp;
	  for(i=1;i<n;i++)
	  {
	   for(j=0;j<i;j++)
	   {
	     if(ar[i]<ar[j])
	     {
		temp=ar[i];
		ar[i]=ar[j];
		ar[j]=temp;
	     }
	   }
	  }
      dis();
}

void accept()
{
 printf("\nEnter how many elements to insert");
 scanf("\n%d",&n);
 printf("\nEnter elements\n");
 for(int i=0;i<n;i++)
 {
   scanf("%d",&ar[i]);
 }
 printf("\nSorted elements are\n");
 sort();
 
}




void bsrch()
{
 int fst,lst,el;
 fst=0;
 lst=n-1;
 int mid;
 mid=(fst+lst)/2;

 printf("\nEnter the element to be searched\t");
 scanf("%d",&el);
 
 while(fst<=lst)
 {
   if(el<ar[mid])
   {
      lst=mid-1;
   }
   else if(el==ar[mid])
   {
     printf("\nElement is found at position %d \n",mid+1);
     return;
   }
   else
   {
      fst=mid+1;
   }
  mid=(fst+lst)/2;
 }
printf("\nElement is not found\n");
}

int main()
{
  accept();
  bsrch();
}

    
