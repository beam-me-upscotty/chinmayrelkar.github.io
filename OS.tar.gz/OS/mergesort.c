#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/wait.h>
int arr[50];
int n;

void readarr()
{
	int i;
	printf("\nHow many elements to be sort ");
	scanf("%d",&n); 
        printf("\nEnter the numbers to be sort\n");
        for(i=0;i<n;i++)
        {
          scanf("\n%d",&arr[i]);
        }
}


void dis()
{
 
	int i;
         printf("\nSorted elements are \n");
	 for(i=0;i<n;i++)
	  {
	    printf("%d\n",arr[i]);
	  }

}

void merge(int list[],int start,int mid,int end)
{
  	int i,start1,start2,end1,end2,temp[50];
  	start1=start;
  	end1=mid;
  	start2=mid+1;
  	end2=end;
  	i=start;
  
  	while(start1<=end1 && start2<=end2)
  	{
    		if(list[start1]<list[start2])
     		{
       			temp[i]=list[start1];
       			start1++;
       			i++;
     		}
    		else if(list[start1]>list[start2])
     		{
       			temp[i]=list[start2];
       			start2++;
       			i++;
     		}
    		else if(list[start1]==list[start2])
     		{
        		temp[i]=list[start1];
        		temp[i+1]=list[start2];
        		start1++;
        		start2++;
        		i=i+2;
     		}
   	}    
    	while(start2<=end2)
     	{
        	temp[i]=list[start2];
        	start2++;
        	i++;
     	}
    	while(start1<=end1)
     	{
        	temp[i]=list[start1];
        	start1++;
        	i++;
     	}	
    	for(i=start;i<=end;i++)
       		list[i]=temp[i];                  
}

void merge_sort(int array[],int start,int end)
{
	    int mid;
	    if(start<end)
	    {
	    		mid=(start+end)/2;
       			merge_sort(array,start,mid);
       			merge_sort(array,mid+1,end);
       			merge(array,start,mid,end);
     	    }  
}

void quicksort(int a[],int left,int right)
{
	 int pivot,i,j,temp;
	 if(left<right)
	 {
		 i=left;
		 pivot=left;
		 j=right;
               while(i<j)
                 {
                   while(a[i]<=a[pivot]&&i<right)
                   {
                     i++;
                   }
                   while(a[j]>a[pivot])
                   {
                     j--;
                   }
		         if(i<j)
		         {
		              temp=a[i];
		              a[i]=a[j];
		             a[j]=temp;
		         }
                 }
            temp=a[pivot];
            a[pivot]=a[j];
            a[j]=temp;
	    quicksort(a,left,j-1);
            quicksort(a,j+1,right);
       }
}
            

              

int main()
{
  readarr();
  
  
   pid_t id;
id=fork();
   if(id<0)
   {
     printf("\nChild process is not created");
   }
   if(id==0)
   {
    
     merge_sort(arr,0,n-1);
     printf("\nSORTED ARRAY AFTER MERGE SORT IS:");
     dis();
   }
   if(id>0)
   { 
     wait(NULL);
     quicksort(arr,0,n-1);
     printf("\nArray after Quick sort is\n");
     dis();
   }
}

