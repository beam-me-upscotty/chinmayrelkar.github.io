
#include<stdio.h>

int a[50];
int n=10;

void read()
{
  int i;
   printf("Enter the array elements:");
   for(i=0;i<n;i++)
    {
      scanf("%d",&a[i]);
    }
}

void dis()
{
  int i;
   for(i=0;i<n;i++)
    {
      printf("%d\n",a[i]);
    }
}

void sort()

{
	  int i,j,temp;
	  for(i=1;i<n;i++)
	  {
	   for(j=0;j<i;j++)
	   {
	     if(a[i]<a[j])
	     {
		temp=a[i];
		a[i]=a[j];
		a[j]=temp;
	     }
	   }
	  }
   printf("\nThe sorted elements are:\n");
   dis();
}
   

int main()
{
  read();
  sort();
}
  
  
 
