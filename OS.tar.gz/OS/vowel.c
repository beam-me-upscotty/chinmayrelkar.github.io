/*
	Implement programs to exhibit UNIX process control 
	Program where child process counts number of vowels in the given sentence 
	and parent process will count number of words in the given sentence.

*/

#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<string.h>
#include<sys/types.h>
#include<sys/wait.h>

int main()
    {
	char str[30],*ptr1;
	int vowel=0,word=1;
        pid_t id;
	printf("\nEnter the string : ");
	gets(str);
	ptr1 = str;
	id = fork();
	if(id < 0)
	{
		printf("\nThe process is not created..!!");
	}
	if(id == 0)
	{
		while(*ptr1 != '\0')
		{
			if(*ptr1=='a' || *ptr1=='e' || *ptr1=='i' || *ptr1=='o' || *ptr1=='u')
			{
				vowel++;
			}
			ptr1++;
		}
		printf("\nThe number of vowels are : %d",vowel);
	}
	if(id > 0)
	{
	        wait(NULL);
		while(*ptr1 != '\0')
		{
			if(*ptr1 == ' ')
			{
				word++;
			}
			ptr1++;
		}
		
		
		printf("\nThe number of words are : %d",word);
	}
}
