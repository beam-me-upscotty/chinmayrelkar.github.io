import weka.core.Instances;
import weka.classifiers.Evaluation;
import weka.classifiers.bayes.NaiveBayes;
import weka.core.converters.ConverterUtils.DataSource;

class Main
{
    public static void main(String [] args)
    {
        try
        {
            // Create an instance for the training set
            DataSource source = new DataSource("/home/shruti/eclipse-workspace/NaiveBayesClassifier/src/dataset/iris-train.arff");
            Instances data = source.getDataSet();

            // Set the index of the class (i.e. the label to be predicted)
            data.setClassIndex(data.numAttributes() - 1);

            // Create and train the classifier
            NaiveBayes clf = new NaiveBayes();
            clf.buildClassifier(data);

            // Create an instance for the test set and set its class index as well
            source = new DataSource("/home/shruti/eclipse-workspace/NaiveBayesClassifier/src/dataset/iris-test.arff");
            data = source.getDataSet();
            data.setClassIndex(data.numAttributes() - 1);

            // Create an Evaluation object.
            Evaluation eval = new Evaluation(data);

            // evaluate the performance of the classifier on the test set
            eval.evaluateModel(clf, data);

            // Print the summary of the evaluation, class wise metrics, and a confusion matrix
            System.out.println(eval.toSummaryString("Summary\n", false));
            System.out.println(eval.toClassDetailsString("Class wise detailed metrics"));
            System.out.println(eval.toMatrixString("Confusion Matrix"));
        }
        catch (Exception e)
        {
            e.printStackTrace();
            System.out.println(e);
        }
    }
}