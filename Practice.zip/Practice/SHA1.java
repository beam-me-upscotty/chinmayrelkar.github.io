import java.util.Scanner;
import java.security.NoSuchAlgorithmException;
import java.security.MessageDigest;

public class SHA1 {
	static String sha(String input) throws NoSuchAlgorithmException{
		MessageDigest md = MessageDigest.getInstance("SHA1");

		byte[] messageDigest = md.digest(input.getBytes());

		System.out.println("Message Digest :");

		for(int i = 0; i < messageDigest.length; i++)
			System.out.print(messageDigest[i]+" ");

		StringBuffer sb = new StringBuffer();

		System.out.println(messageDigest.length);

		for(int i = 0; i < messageDigest.length; i++)
			sb.append(Integer.toHexString(0XFF &messageDigest[i]));

		return sb.toString();
	}

	public static void main(String[] args) throws NoSuchAlgorithmException {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the text you want to hash.");
		String input = scanner.nextLine();
		String output = sha(input);
		System.out.println("The hashed string in hex format is :");
		System.out.println(output);
		scanner.close();
		
		
	}

}
