library("Metrics")
library("lattice")
library("DAAG")
Data <- read.csv("/home/chinmay/Datasets/Advertising.csv")
head(Data)
summary(Data)

Training = Data[1:150,]
Testing = Data[151:200,]

TV <- lm(Sales ~ TV, data = Training)
TV
plot(Training$Sales ~ Training$TV, xlab = "TV", ylab = "Sales")
abline(TV)

Radio <- lm(Sales ~ Radio, data = Training)
Radio
plot(Training$Sales ~ Training$Radio, xlab = "Radio", ylab = "Sales")
abline(Radio)

Newspaper <- lm(Sales ~ Newspaper, data = Training)
Newspaper
plot(Training$Sales ~ Training$Newspaper, xlab = "Newspaper", ylab = "Sales")
abline(Newspaper)

TVTraining <- predict(TV, Training)
RadioTraining <- predict(Radio, Training)
NewspaperTraining <- predict(Newspaper, Training)

TVTesting <- predict(TV, Testing)
RadioTesting <- predict(Radio, Testing)
NewspaperTesting <- predict(Newspaper, Testing)

TVTrainMSE <- mse(Training$Sales, TVTraining)
RadioTrainMSE <- mse(Training$Sales, RadioTraining)
NewspaperTrainMSE <- mse(Training$Sales, NewspaperTraining)

TVTestMSE <- mse(Testing$Sales, TVTesting)
RadioTestMSE <- mse(Training$Sales, RadioTesting)
NewspaperTestMSE <- mse(Training$Sales, NewspaperTesting)

TrainMSE = c(TVTrainMSE, RadioTrainMSE, NewspaperTrainMSE)
TestMSE = c(TVTestMSE, RadioTestMSE, NewspaperTestMSE)

barplot(TrainMSE, width = 0.02, xlab = "Data", ylab = "Error", main ="Training Error")
barplot(TestMSE, width = 0.02, xlab = "Data", ylab = "Error" ,main = "Testing Error")

Model <- cv.lm(Data, (Sales ~ Radio), m = 10)



barplot(Training, width = 0.02, xlab = "Data", ylab = "Error" )
