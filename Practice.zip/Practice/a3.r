library(arules)
library(arulesViz)
library(datasets)

data(Groceries)

itemFrequencyPlot(Groceries, topN = 10)

RHSrules <- apriori(Groceries, parameter = list(support = 0.002, confidence = 0.7), appearance = list(rhs = "whole milk"), control = list(verbose = F))
RHSrules = sort(RHSrules, decreasing = TRUE, by = "confidence")
RHSrules = RHSrules[1:10]
summary(RHSrules)
plot(RHSrules, method = "graph", engine = "interactive")

LHSrules <- apriori(Groceries, parameter = list(support = 0.001, confidence = 0.15), appearance = list(default = "rhs", lhs = "whole milk"), control = list(verbose = F))
LHSrules = sort(LHSrules, decreasing = TRUE, by = "confidence")
LHSrules = LHSrules[1:10]
summary(LHSrules)
plot(LHSrules, method = "graph", engine = "interactive")