from sklearn.cluster import KMeans
from sklearn.datasets import make_blobs
import matplotlib.pyplot as plt

data = make_blobs(n_samples = 200, n_features = 2, centers = 4, random_state = 60, cluster_std = 2.6)
points = data[0]

model = KMeans(n_clusters = 3)
model.fit(points)
y = model.fit_predict(points)
y
print(model.cluster_centers_)

plt.scatter(points[y == 0,0], points[y == 0,1], c = "red")
plt.scatter(points[y == 1,0], points[y == 1,1], c = "green")
plt.scatter(points[y == 2,0], points[y == 2,1], c = "blue")
plt.show()

from sklearn.datasets import make_blobs
import matplotlib.pyplot as plt

from scipy.spatial import distance as dist
import numpy as np
from copy import deepcopy

def kmeans_impl(n_clusters,data): 
	centroid = data[np.random.choice(data.shape[0],n_clusters,replace=False),:]
	old_centroid = np.zeros(centroid.shape)
	correction=centroid-old_centroid
	while np.all(correction != 0): 
		print(centroid)
		labels = np.argmin(dist.cdist(data,centroid),axis=1) 
		old_centroid = deepcopy(centroid) 
		for k in range(n_clusters):
			points = [data[j] for j in range(len(data)) if labels[j]==k]
			centroid[k]=np.mean(points,axis=0)
		correction = centroid-old_centroid
	return np.argmin(dist.cdist(data,centroid),axis=1) 
y = kmeans_impl(3,points)

plt.scatter(points[y == 0,0], points[y == 0,1], c = "red")
plt.scatter(points[y == 1,0], points[y == 1,1], c = "green")
plt.scatter(points[y == 2,0], points[y == 2,1], c = "blue")
plt.show()
