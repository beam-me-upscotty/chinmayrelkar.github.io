from sklearn import svm
from sklearn import datasets
import numpy as np
import matplotlib.pyplot as plt

dataset = datasets.load_iris()
X = dataset.data[:,:2]
y = dataset.target
C = 25

svc = svm.SVC(kernel = 'linear', C = C).fit(X,y)
svc_scores = svc.score(X,y)

linearSVC = svm.LinearSVC(C = C, max_iter = 4000).fit(X,y)
linearSVC_scores = linearSVC.score(X,y)

rbfSVC = svm.SVC(kernel = 'rbf', C = C).fit(X,y)
rbfSVC_scores = rbfSVC.score(X,y)

polySVC = svm.SVC(kernel = 'poly', C = C, degree = 3, gamma = 'auto').fit(X,y)
polySVC_scores = polySVC.score(X,y)

print(svc_scores)
print(linearSVC_scores)
print(rbfSVC_scores)
print(polySVC_scores)

import matplotlib.gridspec as gridspec
import itertools
from mlxtend.plotting import plot_decision_regions

labels = ['SVC', 'Linear', 'RBF', 'Polynomial']
gs = gridspec.GridSpec(2,2)

for clf, lab, grd in zip([svc,linearSVC, rbfSVC, polySVC], labels, itertools.product([0,1],repeat = 2)):
	ax = plt.subplot(gs[grd[0],grd[1]])
	fig = plot_decision_regions(X=X, y=y, clf=clf)
	plt.title(lab)
plt.show()
