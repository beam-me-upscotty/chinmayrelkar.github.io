import pandas as pd
import numpy as np

data = pd.read_csv("/home/shruti/Documents/BE/ML/diabetes.csv")
X = data.iloc[:,:8]
y = data.iloc[:,8]

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2)

from keras.models import Sequential
from keras.layers import Dense

classifier = Sequential()

classifier.add(Dense(init = "uniform", activation = "sigmoid", input_dim = 8, units = 10))
classifier.add(Dense(units = 3, init = "uniform", activation = "relu"))
classifier.add(Dense(units = 1, init = "uniform", activation = "sigmoid"))

classifier.compile(optimizer = "adam", loss = "binary_crossentropy", metrics = ['accuracy'])

classifier.fit(X_train, y_train, batch_size = 10, epochs = 50)

y_pred = classifier.predict(X_test)
y_pred = y_pred > 0.5

from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_test, y_pred)
print(cm[0][0] + cm[1][1]/cm.sum())

from ann_visualizer.visualize import ann_viz
ann_viz(classifier, view = True, filename = "Network graph", title = "Neural Network for Diabetes Dataset")
