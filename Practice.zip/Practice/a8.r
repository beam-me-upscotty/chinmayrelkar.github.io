data <- read.csv("/home/chinmay/Datasets/iris.csv")
data <- data[1:4]
head(data)

pca <- princomp(data)
summary(pca)

screeplot(pca, npcs = min(3), type = c("barplot", "lines"), main = "Scree Plot")
biplot(pca)

head(pca$loadings)
head(pca$scores)
