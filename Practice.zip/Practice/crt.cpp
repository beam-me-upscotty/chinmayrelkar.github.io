	#include<iostream>
using namespace std;
#define SIZE 20
int gcd(int a, int b){
	if(b == 0)
		return a;
	return(gcd(b, a % b));
}

bool coprime(int list[], int totalCongruences){
	for(int i = 0; i < totalCongruences; i++){
		for(int j = i+1; j < totalCongruences; j++){
			if(gcd(list[i], list[j] != 1))
				return false;
		}
	}
	return true;
}

int mod_inverse(int a, int n){
	for(int i = 1; i < n; i++){
		if((a * i) % n == 1){
			return i;
		}
	}
	return -1;
}
int main(){
	int n[SIZE], a[SIZE], totalCongruences, y[SIZE], z[SIZE], x = 0, N = 0;

	cout<<"Enter the number of congruences"<<endl;
	cin>>totalCongruences;

	do{
		cout<<"Enter the system(x = ai mod ni)"<<endl;
		for(int i = 0; i < totalCongruences; i++){
			cout<<"a["<<i<<"]"<<endl;
			cin>>a[i];
			cout<<"n["<<i<<"]"<<endl;
			cin>>n[i];
		}
	}
	while(coprime(n,totalCongruences));

	cout<<"The congruences are : "<<endl;
	for(int i = 0; i < totalCongruences; i++){
		cout<<"x = "<<a[i]<<" (mod "<<n[i]<<")"<<endl;
	}
	N = 1;
	for(int i = 0; i < totalCongruences; i++){
		N = N * n[i];
	}
	cout<<"N = "<<N<<endl;

	for(int i = 0; i < totalCongruences; i++){
		y[i] = N/n[i];
		cout<<"y["<<i<<"] = "<<y[i]<<endl;
		z[i] = mod_inverse(y[i], n[i]);
		cout<<"z["<<i<<"] = "<<z[i]<<endl;
		x += a[i] * y[i] * z[i];
	}
	cout<<"x = "<<x % N<<endl;
}
