#include<iostream>
#include<stdio.h>
#include<math.h>
using namespace std;

double gcd(double a, double b)
{
    if (b == 0)
        return a;
    return gcd(b, fmod(a,b));
}

double power(int a, int b){
    double power = 1;
    for(int i = 0; i < b; i++){
        power = power * a;
    }
    return power;
}
int main(){
    double p1, p2, plaintext, ciphertext, n, phi, e, d;
    cout<<"Enter 1st prime number"<<endl;
    cin>>p1;
    cout<<"Enter 2nd prime number"<<endl;
    cin>>p2;

    n = p1 * p2;
    phi = (p1 - 1) * (p2 - 1);

    do{
      cout<<"Enter the value of e"<<endl;
      cin>>e;
    }while(gcd(e,phi) != 1);

	int casted, i=1;
	while(d != casted){
		d = ((i * phi) + 1)/ e;

		casted = int(d);

		i++;
	}

    cout<<"Public Key : "<<endl;
    cout<< e << "," << n <<endl;

    cout<<"Private Key : "<<endl;
    cout<< d << "," << n << endl;

    cout<<"Enter message "<<endl;
    cin >> plaintext;

    cout<<"Encrpyting message..."<<endl;
    ciphertext = fmod(power(plaintext, e), n);
    cout<<"Cipher Text is :"<<endl;
    cout<<ciphertext<<endl;

    cout<<"Decrypting message..."<<endl;
    plaintext = fmod(power(ciphertext, d), n);
    cout<<"Plaintext is :"<<endl;
    cout<<plaintext<<endl;


}
