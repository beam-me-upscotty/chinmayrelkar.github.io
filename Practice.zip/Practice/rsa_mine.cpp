#include<iostream>

using namespace std;

int generatePrivatekey(int public_key, int ph){
	int i;
	for (i = ph/public_key; (public_key*i)%ph!=1 ; i++);
	return i;
}
int power(int x, int power){
	int ans = 1;
	while(power--){
		ans*=x;
	}
	return ans;
}
int main(){
	// encryption key generation at receiver
	int p, q; // prime
	cout<<"Enter p and q";
	cin>>p>>q;
	int n = p*q;
	int ph = (p-1)*(q-1);
	int public_key = 3; //prime
	int e = generatePrivatekey(public_key,ph);


	// sender encrypting the message using public_key and n from the receiver
	int message;
	cout<<"Enter message";
	cin>>message;
	int c = power(message,public_key)%n;
	cout<<"encrypted:"<<c;

	// sending encrypted message c to receiver
	int d = power(c,e)%n;
	cout<<"decrypted:"<<d;
}