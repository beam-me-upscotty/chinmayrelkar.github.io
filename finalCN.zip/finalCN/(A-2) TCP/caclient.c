#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<netinet/in.h>

int main(){
	struct sockaddr_in saddr;
	int sd , b;
	char operator;
	int num1 , num2 , res;

	sd = socket(AF_INET , SOCK_STREAM , 0);
	if(sd<0){
		printf("Error in creation\n");
		exit(1);
	}
	
	saddr.sin_family = AF_INET;
	saddr.sin_port = htons(8004);
	saddr.sin_addr.s_addr = INADDR_ANY;

	b = connect(sd , (struct sockaddr*) &saddr , sizeof(saddr));
	if(b == -1){
		printf("Connection error\n");
		exit(1);
	}

	printf("Enter operator\n");
	scanf("%c",&operator);
	printf("Enter 1st number\n");
	scanf("%d",&num1);
	printf("Enter 2nd number\n");
	scanf("%d",&num2);

	send(sd , &operator , sizeof(operator) , 0);
	send(sd , &num1 , sizeof(num1) , 0);
	send(sd , &num2 , sizeof(num2) , 0);

	recv(sd , &res , sizeof(res) , 0);
	printf("\nResult is: %d",res);
	close(sd);
}


	
	
