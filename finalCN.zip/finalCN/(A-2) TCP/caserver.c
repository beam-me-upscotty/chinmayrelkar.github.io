#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<netinet/in.h>

int main(){
	struct sockaddr_in saddr , caddr;
	int sd , newsd , b;
	
	sd = socket( AF_INET , SOCK_STREAM , 0);
	if(sd<0){
		printf("Error in creation\n");
		exit(1);
	}
	
	saddr.sin_family = AF_INET;
	saddr.sin_port = htons(8004);
	saddr.sin_addr.s_addr = INADDR_ANY;

	if(bind(sd , (struct sockaddr*) &saddr , sizeof(saddr)) == -1){
		printf("Error in binding\n");
		exit(1);
	}
	
	if(listen(sd , 5) == -1){
		printf("Error in listening\n");
		exit(1);
	}

	printf("server is waiting...\n");
	fflush(stdout);

	b= sizeof(caddr);
	newsd = accept(sd , (struct sockaddr*) &caddr , &b);
	if(newsd == -1){
		printf("Error in accepting\n");
		exit(1);
	}

	char op;
	int num1 , num2 , res;
	recv(newsd , &op , sizeof(op) , 0);
	recv(newsd , &num1 , sizeof(num1) , 0);
	recv(newsd , &num2 , sizeof(num2) , 0);

	switch(op){
		case '+' :
			res = num1 + num2;
			printf("Addition\n");
			break;
		case '-' :
			res = num1-num2;
			printf("Subtraction\n");
			break;
		case '*' :
			res = num1*num2;
			printf("Multiplication\n");
			break;
		case '/' : 
			res = num1/num2;
			printf("Division\n");
			break;
		default:
			printf("Invalid operation\n");
	}
	
	send(newsd , &res , sizeof(res) , 0);
	close(newsd);
}
	

	
