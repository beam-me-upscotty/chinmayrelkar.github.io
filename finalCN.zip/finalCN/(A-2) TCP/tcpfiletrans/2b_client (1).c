#include<stdlib.h>
#include<string.h>
#include<stdio.h>
#include<netinet/in.h>
#include<sys/socket.h>

#define PORT 8081

int main()
{

	int sock,new_sock;
	struct sockaddr_in address;
	int sockaddr_len=sizeof(address);
	char buffer[1000]={0};
	char *temp="hello frommm client";
	
	if((sock=socket(AF_INET,SOCK_STREAM,0))==-1)
	{
		perror("socket failed");
		return -1;
	}

	address.sin_port=htons(PORT);
	address.sin_family=AF_INET;

	if(inet_pton(AF_INET,"127.0.0.1",&address.sin_addr)<=0)
	{
		perror("\nInvalid address/ Address not supported \n");
		return -1;
	}

	if(connect(sock,(struct sockaddr*)&address,sockaddr_len)==-1)
	{
		printf("connection Failed");
		return -1;
	}

	FILE *fp;

	fp=fopen("file.txt","r");
	
	
	while(fgets(buffer,1000,(FILE*)fp)!=NULL)
	{
		printf("%s\n",buffer);
		write(sock,buffer,strlen(buffer));
	}

	char *DONE="Doooone";
	write(sock,DONE,strlen(DONE));

	//close(fp);
	//close(sock);
	return 0;
}
