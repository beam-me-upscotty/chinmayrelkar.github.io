#include<stdlib.h>
#include<string.h>
#include<stdio.h>
#include<netinet/in.h>
#include<sys/socket.h>

#define PORT 8081

int main()
{

	int sock,new_sock,opt=1;
	struct sockaddr_in address;
	int sockaddr_len=sizeof(address);
	char buffer[100]={0};
	char tempbuff[100]={0};
	
	if((sock=socket(AF_INET,SOCK_STREAM,0))==-1)
	{
		perror("socket failed");
		return -1;
	}

	if (setsockopt(sock, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt)))
    	{
		perror("setsockopt");
		exit(EXIT_FAILURE);
	}

	address.sin_port=htons(PORT);
	address.sin_addr.s_addr=INADDR_ANY;
	address.sin_family=AF_INET;

	if(bind(sock,(struct sockaddr*)&address,sockaddr_len)==-1)
	{
		perror("bind failed");
		return -1;
	}

	if(listen(sock,3)<0)
	{
		perror("listen failed");
		return -1;	
	}

	if((new_sock=accept(sock,(struct sockaddr*)&address,(socklen_t*)&sockaddr_len))<0)
	{
		perror("listen failed");
		return -1;	
	}

	FILE *fp;

	fp=fopen("new.txt","w");


	do
	{
		memcpy(buffer,tempbuff,sizeof(tempbuff));
		read(new_sock,buffer,100);
		if(strcmp(buffer,"Doooone"))
		{		
			printf("%s",buffer);
			fputs(buffer,(FILE*)fp);
		}
	}while(strcmp(buffer,"Doooone"));

	printf("%s",buffer);

	//close(sock);
	//close(fp);
	return 0;
}
