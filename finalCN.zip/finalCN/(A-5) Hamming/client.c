#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<netinet/in.h>

int main(){
	struct sockaddr_in saddr;
	int sd , b;
	
	sd = socket(AF_INET  , SOCK_STREAM , 0);
	if(sd < 0){
		printf("Error in creation\n");
		exit(1);
	}
	
	saddr.sin_family = AF_INET;
	saddr.sin_port = htons(5000);
	saddr.sin_addr.s_addr = INADDR_ANY;

	b= connect(sd , (struct sockaddr*) &saddr , sizeof(saddr));
	if(b == -1){
		printf("Error in correction\n");
		exit(1);
	}

	int code[7];
	
	printf("Enter the 4-bit code\n");
	scanf("%d",&code[0]);
	scanf("%d",&code[1]);
	scanf("%d",&code[2]);
	scanf("%d",&code[4]);

	code[6] = code[0] ^ code[2] ^ code[4];
	code[5] = code[0] ^ code[1] ^ code[4];
	code[3] = code[0] ^ code[1] ^ code[2];

	code[3] = 1;

	send(sd , code , sizeof(code) , 0);

	close(sd);
}
