#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<netinet/in.h>

int main(){
	struct sockaddr_in saddr,caddr;
	int sd ,newsd , b;
	
	sd = socket(AF_INET , SOCK_STREAM , 0);
	if(sd<0){
		printf("Error in socket creation\n");
		exit(1);
	}

	saddr.sin_family = AF_INET;
	saddr.sin_port = htons(5000);
	saddr.sin_addr.s_addr = INADDR_ANY;

	if(bind(sd , (struct sockaddr*) &saddr , sizeof(saddr)) == -1){
		printf("Bindin error\n");
		exit(1);
	}
	
	if(listen(sd , 5) == -1){
		printf("Listening error\n");
		exit(1);
	}

	printf("server is waiting\n");
	fflush(stdout);

	b = sizeof(caddr);
	newsd = accept(sd , (struct sockaddr*) &caddr , &b);
	if(newsd == -1){
		printf("Error in accepting\n");
	}

	int code[7];
	int num[3];
	int temp , ans;

	recv(newsd , code , sizeof(code) , 0);

	printf("\nRecieved code is : ");

	int i;
	for(i=0;i<7;i++)
		printf("%d",code[i]);

	printf("\n");

	temp = code[0] ^ code[1] ^ code[2] ^ code[3];
	if(temp == 0)
		num[0]=0;
	else
		num[0]=1;

	temp = code[0] ^ code[1] ^ code[4] ^ code[5];
	if(temp == 0)
		num[1]=0;
	else
		num[1]=1;

	temp = code[0] ^ code[2] ^ code[4] ^ code[6];
	if(temp == 0)
		num[2]=0;
	else
		num[2]=1;

	ans = (num[2]*1) + (num[1]*2) + (num[0]*4);

	if(ans == 0)
		printf("\nNo error\n");
	else{
		printf("Error in %d bit",ans);
		if(code[7 - ans] == 0)
			code[7 - ans] = 1;
		else
			code[7 - ans] = 0;
		printf("\nCorrected code is : ");
		for(i=0;i<7;i++)
			printf("%d",code[i]);
	}
	
	close(newsd);
}
