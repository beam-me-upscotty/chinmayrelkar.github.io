import java.net.*;
import java.io.*;
import java.util.*;

public class server{
	public static void main(String args[]){
		while(true){
			try{
			ServerSocket ListenSocket = new ServerSocket(7896);
			Socket clientSocket = ListenSocket.accept();
			System.out.println("Client Connected");
			Connection connection = new Connection(clientSocket);
			}
			catch(Exception e){
				System.out.println(e);
			}
		}
	}
}

class Connection extends Thread{
	DataInputStream in;
	DataOutputStream out;
	Socket clientSocket;
	public Connection(Socket aClientSocket){
		try{
				clientSocket = aClientSocket;
			in = new DataInputStream(clientSocket.getInputStream());
			out = new DataOutputStream(clientSocket.getOutputStream());
			this.start();
		}
		catch(Exception e){
			System.out.println(e);
		}
	}
	public void run(){
		try{
			String data = in.readUTF();
			System.out.println("Client with id "+getId()+" said this "+data);
			out.writeUTF(data);
			clientSocket.close();
		}
		catch(Exception e){
			System.out.println(e);
		}
	}
}
