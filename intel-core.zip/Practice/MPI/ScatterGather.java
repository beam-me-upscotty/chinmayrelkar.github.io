import mpi.MPI;
public class ScatterGather{
	public static void main(String args[]){
		MPI.Init(args);
		int rank = MPI.COMM_WORLD.Rank();
		int size = MPI.COMM_WORLD.Size();
		int root = 0;
		int sendBuf[] = new int[size];

		if(rank == root){
			sendBuf[0] = 10;
			sendBuf[1] = 20;
			sendBuf[2] = 30;
			sendBuf[3] = 40;

			System.out.println("Processor "+rank+" has following data");
			for(int i = 0; i < size; i++){
				System.out.print(sendBuf[i] + " ");
			}
		}

		int recBuf[]  = new int[1];

		MPI.COMM_WORLD.Scatter(sendBuf, 0, 1, MPI.INT, recBuf, 0, 1, MPI.INT, root);
		System.out.println("Processor "+rank+" has data "+recBuf[0]);
		System.out.println("Processor "+rank+" is doubling data");

		recBuf[0]*=2;

		MPI.COMM_WORLD.Gather(recBuf, 0, 1, MPI.INT, sendBuf, 0, 1, MPI.INT, root);
		if(rank == root){
			System.out.println("Processor "+rank+" has following data");
			for(int i = 0; i < size; i++){
				System.out.println(sendBuf[i] + " ");
			}
		}
		MPI.Finalize();
	}
}
