import java.net.*;
import java.io.*;
import java.rmi.*;
import java.util.*;

public class Client{
	public static void main(String args[]){
		try{
			String URL = "rmi://localhost/Server";
			ServerIntf serverintf = (ServerIntf)Naming.lookup(URL);

			Scanner in = new Scanner(System.in);
			String s1 = in.nextLine();
			String s2 = in.nextLine();

			System.out.println(serverintf.concat(s1,s2));
		}
		catch(Exception e){
			System.out.println(e);
		}
	}
}
