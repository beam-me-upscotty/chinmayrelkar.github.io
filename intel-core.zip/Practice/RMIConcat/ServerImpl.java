import java.net.*;
import java.rmi.*;
import java.rmi.server.*;

public class ServerImpl extends UnicastRemoteObject implements ServerIntf{
	public ServerImpl() throws RemoteException{

	}
	public String concat(String s1, String s2) {
		return s1+s2;
	}
}
