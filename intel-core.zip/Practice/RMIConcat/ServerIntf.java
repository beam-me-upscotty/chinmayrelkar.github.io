import java.net.*;
import java.rmi.*;

public interface ServerIntf extends Remote{
	public String concat(String s1, String s2) throws RemoteException;
}
