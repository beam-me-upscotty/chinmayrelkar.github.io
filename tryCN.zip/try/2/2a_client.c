#include<stdlib.h>
#include<string.h>
#include<stdio.h>
#include<sys/socket.h>
#include<netinet/in.h>

#define PORT 8081

int main()
{

	int sock_fd;
	struct sockaddr_in serv_addr;
	char *hello="hello from client";
	char buffer[1024]={0};

	if((sock_fd=socket(AF_INET,SOCK_STREAM,0))==-1)
	{
		perror("socket failed");
		exit(EXIT_FAILURE);
	}

	serv_addr.sin_family = AF_INET;
    	serv_addr.sin_port = htons(PORT);

	if(inet_pton(AF_INET,"127.0.0.1",&serv_addr.sin_addr)<=0)
	{
		printf("\nInvalid address/ Address not supported \n");
        	return -1;	
	}

	if(connect(sock_fd,(struct sockaddr*)&serv_addr,sizeof(serv_addr))<0)
	{
		printf("connection Failed");
		return -1;
	}

	send(sock_fd,hello,strlen(hello),0);
	read(sock_fd,buffer,1024);
	printf("%s\n",buffer );	

	
	return 0;
}
