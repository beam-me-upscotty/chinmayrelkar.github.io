#include<stdlib.h>
#include<string.h>
#include<stdio.h>
#include<netinet/in.h>
#include<sys/socket.h>

#define PORT 8081

int main()
{

	int sock,new_sock,opt=1;
	struct sockaddr_in address;
	int sockaddr_len=sizeof(address);
	char buffer[1024]={0},filename[20];
	char tempbuff[100]={0};
	
	if((sock=socket(AF_INET,SOCK_DGRAM,0))==-1)
	{
		perror("socket failed");
		return -1;
	}

	if (setsockopt(sock, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt)))
    	{
		perror("setsockopt");
		exit(EXIT_FAILURE);
	}

	address.sin_port=htons(PORT);
	address.sin_addr.s_addr=INADDR_ANY;
	address.sin_family=AF_INET;

	if(bind(sock,(struct sockaddr*)&address,sockaddr_len)==-1)
	{
		perror("bind failed");
		return -1;
	}

	FILE *fp;
	printf("\nEnter name of file :");
	scanf("%s",filename);

	fp=fopen(filename,"wb");
	do
	{
		if((recvfrom(sock,buffer,1024,0,(struct sockaddr*)&address,(socklen_t*)&sockaddr_len)<0))
		{
			perror("recieve failed");
			return -1;
		}
		else
		{
			if(strcmp(buffer,"Doooone"))
			{		
				//printf("%s",buffer);
				fwrite(buffer,1024,1,fp);
			}
		}
	}while(strcmp(buffer,"Doooone"));

	//close(fp);
	//close(sock);
	return 0;
}
