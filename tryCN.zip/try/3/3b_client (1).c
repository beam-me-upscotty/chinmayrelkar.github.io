#include<stdlib.h>
#include<string.h>
#include<stdio.h>
#include<netinet/in.h>
#include<sys/socket.h>

#define PORT 8081

int main()
{

	int sock,new_sock;
	struct sockaddr_in address;
	int sockaddr_len=sizeof(address);
	char buffer[1024]={0},filename[20];
	char *temp="hello frommm client";
	
	if((sock=socket(AF_INET,SOCK_DGRAM,0))==-1)
	{
		perror("socket failed");
		return -1;
	}

	address.sin_port=htons(PORT);
	address.sin_family=AF_INET;
	address.sin_addr.s_addr=inet_addr("127.0.0.1");

	FILE *fp;
	printf("\nEnter name of file :");
	scanf("%s",filename);

	fp=fopen(filename,"r");
	fseek(fp,0,0);
	while(fgets(buffer,1000,(FILE*)fp)!=NULL)
	{
		printf("%s",buffer);
		if(sendto(sock,buffer,1024,0,(struct sockaddr*)&address,sockaddr_len)<0)
		{
			perror("recieve failed");
			return -1;
		}
		usleep(1000);
		
	}

	strcpy(buffer,"Doooone");
	sendto(sock,buffer,1024,0,(struct sockaddr*)&address,sockaddr_len);

	//close(sock);
	//close(fp);
	return 0;
}
