import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {

	public static void main(String[] args) throws UnknownHostException, IOException {
		// TODO Auto-generated method stub
		
		DataInputStream dis;
		DataOutputStream dos;
		Socket soc;
		Scanner sc=new Scanner(System.in);
		
		soc=new Socket("127.0.0.1",8000);
		dis=new DataInputStream(soc.getInputStream());
		dos=new DataOutputStream(soc.getOutputStream());
		
		System.out.println(dis.readUTF());
		dos.writeUTF("hiiiiii");
		
		int a[]= {0,0,0,0,0,0,0,0,0};
		int ack[]= {0,0,0,0,0,0,0,0,0};
		int size=3;
		int j=0;
		while(j<10-2)
		{
			for(int i=0;i<3;i++)
			{
				a[j+i]=dis.readInt();
			}
			for(int i=0;i<3;i++)
			{
				System.out.println("Enter ack for "+(j+i));
				ack[j+i]=sc.nextInt();
				dos.writeInt(ack[j+i]);
				dos.flush();
				if(ack[j+i]==0)
				{
					a[j+i]=0;
				}
			}
			int k=j;
			for(int i=0;i<3;i++)
			{
				if(ack[j+i]==0)
				{
					a[j+i]=dis.readInt();
					System.out.println("Enterrrr ack for "+(j+i));
					ack[j+i]=sc.nextInt();
					dos.writeInt(ack[j+i]);
					dos.flush();
					if(ack[j+i]==0)
						i--;
					else
					{
						k++;
					}
					
				}
				else
					k++;
			}
			j=k;
		}
		
		System.out.println("Array :");
		for(int i=0;i<9;i++)
			System.out.print(a[i]+"\t");
		
		System.out.print("\nAck :");
		for(int i=0;i<9;i++)
			System.out.print(ack[i]+"\t");
		
		
		dos.close();
		dis.close();
		soc.close();

	}

}
