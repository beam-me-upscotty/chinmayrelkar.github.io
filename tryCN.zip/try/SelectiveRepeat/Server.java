import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
	

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		DataInputStream dis;
		DataOutputStream dos;
		ServerSocket soc;
		
		soc=new ServerSocket(8000);
		System.out.println("Waiting for connection");
		Socket client=soc.accept();
		dis=new DataInputStream(client.getInputStream());
		dos=new DataOutputStream(client.getOutputStream());
		dos.writeUTF("hii");
		dos.flush();
		System.out.println(dis.readUTF());
		
		int a[]= {10,20,30,40,50,60,70,80,90};
		int ack[]= {0,0,0,0,0,0,0,0,0};
		int size=3;
		int j=0;
		while(j<10-3)
		{
			for(int i=0;i<3;i++)
			{
				dos.writeInt(a[j+i]);
				dos.flush();
			}
			for(int i=0;i<3;i++)
			{
				ack[j+i]=dis.readInt();
			}
			int k=j;
			for(int i=0;i<3;i++)
			{
				if(ack[j+i]==0)
				{
					dos.writeInt(a[j+i]);
					dos.flush();
					System.out.println("Resending Packet :"+(j+i));
					ack[j+i]=dis.readInt();
					if(ack[j+i]==0)
						i--;
					else
					{
						k++;
					}
					
				}
				else
					k++;
			}
			j=k;
		}
		
		dos.close();
		dis.close();
		soc.close();

	}

}
