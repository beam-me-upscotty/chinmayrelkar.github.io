import java.util.Scanner;

public class Subn {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Enter the ip address :");
		Scanner sc=new Scanner(System.in);
		String ip=sc.nextLine();
		String split_ip[]=ip.split("\\.");
		String split_bip[]=new String[4];
		String bip="";
		String mask1="";
		int host=8;
		
		int firstoctet=Integer.parseInt(split_ip[0]);
		if(firstoctet<128)
		{
			host=24;
			mask1="255.0.0.0";
			System.out.println("Class A IP Address");
            System.out.println("Default mask is: "+mask1);
		}
		else if(firstoctet<192)
		{
			host=16;
			mask1="255.255.0.0";
			System.out.println("Class B IP Address");
            System.out.println("Default mask is: "+mask1);
		}
		else if(firstoctet<224)
		{
			host=8;
			mask1="255.255.255.0";
			System.out.println("Class C IP Address");
            System.out.println("Default mask is: "+mask1);
		}
			
		for(int i=0;i<4;i++)
		{
			split_bip[i]= appendZeros(Integer.toBinaryString(Integer.parseInt(split_ip[i])));
			bip+=split_bip[i];
		}
		
		System.out.println("IP in binary is "+bip);
		System.out.print("Enter the number of subnets: ");
		int n = sc.nextInt();
		
		int y=(int)Math.ceil(Math.log(n)/Math.log(2));
		System.out.println("Number of bits borrowd from host to network are = "+y);
	
		int z=host-y;
		System.out.println("Number of host bits are = "+z);
		
		int mask=(int)(256-(Math.pow(2.0,(8-y))));
		System.out.println("New subnet mask is = "+mask);
		
		System.out.println("Subnet Size = "+Math.pow(2.0,z));
		
		int fbip[] = new int[32];
		for(int i=0; i<32;i++)
			
			{
				fbip[i] = (int)bip.charAt(i)-48; //convert cahracter 0,1 to integer 0,1
				//System.out.println(fbip[i]);
			}
		
		//System.out.println(fbip);
		for(int i=31;i>31-z;i--)//Get first address by ANDing last n bits with 0
			fbip[i] &= 0;
		//System.out.println(fbip);
		String fip[] ={"","","",""};
		//System.out.println(fip);
		for(int i=0;i<32;i++)
			fip[i/8] = new String(fip[i/8]+fbip[i]);
		System.out.println("first Subnet Details");
		System.out.print("first N/W address is = ");
		for(int i=0;i<4;i++){
			System.out.print(Integer.parseInt(fip[i],2));
			if(i!=3) 
				System.out.print(".");
		}
		
		int lbip[] = new int[32];
		for(int i=0; i<32;i++) 
		lbip[i] = (int)bip.charAt(i)-48; //convert cahracter 0,1 to integer 0,1
		for(int i=31;i>31-z;i--)//Get last address by ORing last n bits with 1
		lbip[i] |= 1;
		String lip[] = {"","","",""};
		for(int i=0;i<32;i++)
			lip[i/8] = new String(lip[i/8]+lbip[i]);
		System.out.println("Broadcast address is = ");
		for(int i=0;i<4;i++){
			System.out.print(Integer.parseInt(lip[i],2));
			if(i!=3)
				System.out.print(".");
		}

	}
			
	static String appendZeros(String s)
	{
		String temp=new String("00000000");
		return temp.substring(s.length())+s;
	}

}
