#include<stdlib.h>
#include<string.h>
#include<stdio.h>
#include<sys/socket.h>
#include<netinet/in.h>

#define PORT 8081

char xor(char a,char b)
{
	if(a=='1'&&b=='1')
		return '0';
	else if(a=='0'&&b=='0')
		return '0';
	else
		return '1';
}

int main()
{

	int sock_fd;
	struct sockaddr_in serv_addr;

	if((sock_fd=socket(AF_INET,SOCK_STREAM,0))==-1)
	{
		perror("socket failed");
		exit(EXIT_FAILURE);
	}

	serv_addr.sin_family = AF_INET;
    	serv_addr.sin_port = htons(PORT);
	serv_addr.sin_addr.s_addr=inet_addr("127.0.0.1");

	if(connect(sock_fd,(struct sockaddr*)&serv_addr,sizeof(serv_addr))<0)
	{
		printf("connection Failed");
		return -1;
	}	

	char maindata[20],gen[10],temp[30];
	int ml,gl,tl;
	printf("\nEnter maindata :");
	scanf("%s",maindata);
	ml=strlen(maindata);

	printf("\nEnter generator :");
	scanf("%s",gen);
	gl=strlen(gen);

	for(int i=0;i<ml;i++)
		temp[i]=maindata[i];

	for(int i=ml;i<ml+gl-1;i++)
		temp[i]='0';
		
		temp[ml=gl-1] = '\0';

	printf("\n%s\n",temp);

	
	int i=0;
	while(i<ml-1)
	{
		while(temp[i]!='1')
			i++;
		if(i>=ml)
			break;
		for(int j=0;j<gl;j++)
		{
			temp[i+j]=xor(temp[i+j],gen[j]);
		}
	}
	int c=0;
	printf("\nReaminder :");
	for(int k=0;k<gl;k++)
	{
		maindata[ml+k]=temp[ml+k];
		printf("%c",temp[ml+k]);
		if(maindata[ml+k]!='\0')
			c=c+(maindata[ml+k]-'0');
	}
	
	printf("\n%d",c);		
	printf("\n%s",maindata);
	write(sock_fd,maindata,30);
	
	return 0;
}
