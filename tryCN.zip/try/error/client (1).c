#include<stdlib.h>
#include<string.h>
#include<stdio.h>
#include<sys/socket.h>
#include<netinet/in.h>

#define PORT 8081

int main()
{

	int sock_fd;
	struct sockaddr_in serv_addr;

	if((sock_fd=socket(AF_INET,SOCK_STREAM,0))==-1)
	{
		perror("socket failed");
		exit(EXIT_FAILURE);
	}

	serv_addr.sin_family = AF_INET;
    	serv_addr.sin_port = htons(PORT);
	serv_addr.sin_addr.s_addr=inet_addr("127.0.0.1");

	if(connect(sock_fd,(struct sockaddr*)&serv_addr,sizeof(serv_addr))<0)
	{
		printf("connection Failed");
		return -1;
	}	

	char data[7];
	char datasend[10];

	printf("\nEnter 4 bits of data :\n");
	scanf("%s",&data[0]);
	scanf("%s",&data[1]);
	scanf("%s",&data[2]);
	scanf("%s",&data[4]);

	
	data[6]=data[4]^data[2]^data[0];
	data[5]=data[4]^data[1]^data[0];
	data[3]=data[2]^data[1]^data[0];

	printf("\nEncoded bits are :");
	printf("%s",data);

	printf("\nEnter bits to be send :\n");
	scanf("%s",datasend);

	send(sock_fd,datasend,10,0);

	
	return 0;
}
