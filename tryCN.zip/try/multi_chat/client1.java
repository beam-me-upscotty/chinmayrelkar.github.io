//package multichattcp;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.UnknownHostException;

public class client1 {

	public static void main(String[] args) throws UnknownHostException, IOException {
	Socket s=new Socket("localhost",6066);
	DataInputStream dis=new DataInputStream(s.getInputStream());
	DataOutputStream dop=new DataOutputStream(s.getOutputStream());
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	String message;
	while(true)
	{
		System.out.print("<Client-1>:\t");
		message=br.readLine();
		dop.writeUTF(message);
		if(message.equals("stop"))break;
		message=dis.readUTF();
		System.out.print("Server to <Client-1>: "+message);
	}
	s.close();
	}

}
