

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class server {

	public static void main(String[] args) throws IOException {
		int count=0;
		ServerSocket ss=new ServerSocket(6066);
		System.out.println("Server is waiting..........");
		while(true)
		{
			++count;
			Socket s=ss.accept();
			ThreadClass tc=new ThreadClass(s,count);
			tc.start();
		}
	}

}
class ThreadClass extends Thread{
	Socket sc;
	String message;
	int num;
	public ThreadClass() {
	
	}

	public ThreadClass(Socket s,int count)
	{
		num=count;
		this.sc=s;
	}
	
	public void run()
	{
		try 
		{
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			DataInputStream dis=new DataInputStream(sc.getInputStream());
			DataOutputStream dop=new DataOutputStream(sc.getOutputStream());
			while(true)
			{
				//synchronized (this) {
					message=dis.readUTF();
					System.out.print("<Client-"+num+">: "+message);
					if(message.equals("stop"))break;
					
					System.out.print("\nServer Says: ");
					message=br.readLine();
					dop.writeUTF(message);
					//	}
						
								
			}
		
		} catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
