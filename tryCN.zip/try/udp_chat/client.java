import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;


public class client {

	public static void main(String[] args) throws IOException {
		String message;
		DatagramSocket ds=new DatagramSocket();
		byte[] senddata=new byte[10];
		byte[] getdata=new byte[10];
		System.out.println("client socket is created");
		InetAddress ip=InetAddress.getByName("localhost");
		int port=8067;
		BufferedReader bf=new BufferedReader(new InputStreamReader(System.in));
		while(true)
		{
			System.out.print("Client says: ");
			message = bf.readLine();
			if(message.equals("end"))break;
			senddata=message.getBytes();
			DatagramPacket sdp=new DatagramPacket(senddata,senddata.length,ip,port);
			ds.send(sdp);
			DatagramPacket rdp=new DatagramPacket(getdata,getdata.length);
			ds.receive(rdp);
			message=new String(rdp.getData(),0,rdp.getLength());
			System.out.println("Server says: "+message);
		}
		ds.close();
	}

}
