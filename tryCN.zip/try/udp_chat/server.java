import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;


public class server
{
	public static void main(String[] args) throws IOException 
	{
		String message;
		DatagramSocket ds=new DatagramSocket(8067);
		byte[] senddata=new byte[10];
		byte[] getdata=new byte[10];
		BufferedReader bf=new BufferedReader(new InputStreamReader(System.in));
	
		int port;
		while(true)
		{
			DatagramPacket rdp=new DatagramPacket(getdata,getdata.length);
			ds.receive(rdp);
			message=new String(rdp.getData(),0,rdp.getLength());
			System.out.println("Client says: "+message);
			System.out.println("Server says: ");
			message=bf.readLine();
			senddata=message.getBytes();
			if(message.equals("end"))break;
			InetAddress ip=rdp.getAddress();
			port=rdp.getPort();
			DatagramPacket sdp=new DatagramPacket(senddata,senddata.length,ip,port);
			ds.send(sdp);
		}
		ds.close();
	}

}
